package com.yash.Advance;

public class ProgramTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
