package com.yash.basic;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Program5Test {
	Program5 obj = new Program5();

	@Test
	public void testExpressionResult() {
		assertEquals(6, obj.findExpressionResult("8*3/4"));
	}
}
