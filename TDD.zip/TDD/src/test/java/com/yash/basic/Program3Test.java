package com.yash.basic;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Program3Test {
	Program3 e = new Program3();
	
    @Test
    public void testFindTotalEvenOddDigit1(){  
    	assertEquals("3 4",e.findTotalEvenOddDigit(1234567));  
    } 
    
}
