package com.yash.intermediate;

public class Program1 {
	 public char testCharAtMethod(String s, int index) {
		 return s.charAt(index);
	 }
	 
	 public String testConcatMethod(String s1, String s2) {
		 return s1.concat(s2);
	 }
	 
	 public boolean testContainMethod(String s1, String s2) {
		 return s1.contains(s2);
	 }
	 
	 public boolean testEndWithMethod(String s1, String s2) {
		 return s1.endsWith(s2);
	 }
}
