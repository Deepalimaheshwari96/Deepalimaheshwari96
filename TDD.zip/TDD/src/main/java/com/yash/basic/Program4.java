package com.yash.basic;

public class Program4 {
     
     public int sumOfDigitFromExpression(String s) {
    	 
    	 Integer totalSum = 0;
		String arr[] = s.split("\\+");
		for (String value : arr) {
			totalSum += Integer.parseInt(value.trim());
		}
		return totalSum;
		}
}
