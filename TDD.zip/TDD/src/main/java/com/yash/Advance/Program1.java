package com.yash.Advance;

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
